 import React, { useState } from "react";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import ProductDetail from "./pages/ProductDetail";
import Cart from "./pages/Cart";
import Checkout from "./pages/Checkout";
import Login from "./pages/Login";

function App() {
  const [page, setPage] = useState("home");
  const [selected, setSelected] = useState(null);
  const [cart, setCart] = useState([]);
  const [user, setUser] = useState(null);

  return (
    <div>
      <Navbar page={page} setPage={setPage} cart={cart} user={user} />

      {page === "home" && <Home setSelected={setSelected} setPage={setPage} />}
      {page === "product" && <ProductDetail product={selected} setCart={setCart} setPage={setPage} />}
      {page === "cart" && <Cart cart={cart} setCart={setCart} setPage={setPage} />}
      {page === "checkout" && <Checkout />}
      {page === "login" && <Login setUser={setUser} setPage={setPage} />}
    </div>
  );
}

export default App;
