import React, { useState } from "react";

export default function Login({ setUser, setPage }) {
  const [name, setName] = useState("");

  return (
    <div style={{ padding:"20px" }}>
      <input placeholder="Enter Name" onChange={e=>setName(e.target.value)} />
      <button onClick={()=>{ setUser(name); setPage("home"); }} style={{ marginLeft:"10px" }}>Login</button>
    </div>
  );
}
