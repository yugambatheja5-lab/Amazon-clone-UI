import React from "react";

export default function Checkout() {
  return (
    <div style={{ padding:"20px" }}>
      <h2>Checkout</h2>
      <input placeholder="Name" /><br/>
      <input placeholder="Address" /><br/>
      <input placeholder="City" /><br/>
      <input placeholder="Pincode" /><br/>
      <button style={{ marginTop:"10px" }}>Place Order</button>
    </div>
  );
}
