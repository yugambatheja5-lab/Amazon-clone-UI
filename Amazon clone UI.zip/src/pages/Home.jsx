import React from "react";
import products from "../data/products";
import ProductCard from "../components/ProductCard";

export default function Home({ setSelected, setPage }) {
  return (
    <div>
      {products.map(p => (
        <ProductCard key={p.id} product={p} setSelected={setSelected} setPage={setPage} />
      ))}
    </div>
  );
}
