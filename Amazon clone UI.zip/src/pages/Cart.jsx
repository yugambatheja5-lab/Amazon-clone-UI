import React from "react";

export default function Cart({ cart, setCart, setPage }) {
  const total = cart.reduce((sum, item) => sum + item.price, 0);

  return (
    <div style={{ padding: "20px" }}>
      <h2>Cart</h2>
      {cart.map((item, i) => (
        <div key={i} style={{ marginBottom:"10px" }}>
          {item.title} - ₹{item.price}
          <button style={{ marginLeft:"10px" }} onClick={()=>setCart(cart.filter((_,index)=>index!==i))}>Remove</button>
        </div>
      ))}
      <h3>Total: ₹{total}</h3>
      <button onClick={()=>setPage("home")}>Continue Shopping</button>
    </div>
  );
}
