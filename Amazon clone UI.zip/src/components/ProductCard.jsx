import React from "react";

export default function ProductCard({ product, setSelected, setPage }) {
  return (
    <div style={{ border:"1px solid gray", padding:"10px", margin:"10px", display:"inline-block", width:"150px" }}>
      <img src={product.image} alt={product.title} />
      <h3>{product.title}</h3>
      <p>₹{product.price}</p>
      <p>⭐ {product.rating}</p>
      <button onClick={()=>{ setSelected(product); setPage("product") }}>View</button>
    </div>
  );
}
