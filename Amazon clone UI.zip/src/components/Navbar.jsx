import React from "react";

export default function Navbar({ page, setPage, cart, user }) {
  return (
    <nav style={{ display:"flex", justifyContent:"space-between", padding:"10px", background:"#232f3e", color:"white" }}>
      <h2 style={{ cursor:"pointer" }} onClick={()=>setPage("home")}>Amazon</h2>
      <div>
        <button onClick={()=>setPage("cart")}>Cart ({cart.length})</button>
        {user ? <span style={{marginLeft:"10px"}}>Hello {user}</span> : <button onClick={()=>setPage("login")}>Login</button>}
      </div>
    </nav>
  );
}
