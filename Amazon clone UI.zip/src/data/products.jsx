const products = [
  { id: 1, title: "Phone", price: 50000, rating: 4.5, image: "https://via.placeholder.com/150", description: "Smartphone" },
  { id: 2, title: "Laptop", price: 70000, rating: 4.2, image: "https://via.placeholder.com/150", description: "Gaming Laptop" }
];

export default products;
